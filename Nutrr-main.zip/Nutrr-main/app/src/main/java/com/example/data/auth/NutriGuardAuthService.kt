package com.example.data.auth

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException

data class DeviceTokenResponse(
    val accessToken: String,
    val refreshToken: String,
    val tokenType: String = "Bearer",
    val expiresIn: Long = 3600,
    val userId: String? = null
)

class NutriGuardAuthService(
    private val httpClient: OkHttpClient,
    private val tokenStore: AuthTokenStore
) {
    private val baseUrl: String = BuildConfig.BACKEND_BASE_URL.trimEnd('/')

    /**
     * Authenticates the device using anonymous device authentication:
     * POST /api/v1/auth/device
     */
    suspend fun authenticateDevice(appVersion: String = "1.0.0"): Result<DeviceTokenResponse> = withContext(Dispatchers.IO) {
        val deviceId = tokenStore.getDeviceId()
        val endpointUrl = "$baseUrl/api/v1/auth/device"

        val jsonPayload = JSONObject().apply {
            put("device_id", deviceId)
            put("app_version", appVersion)
            put("platform", "ANDROID")
        }

        Log.d(TAG, "Executing device authentication to $endpointUrl")

        val request = Request.Builder()
            .url(endpointUrl)
            .post(jsonPayload.toString().toRequestBody("application/json".toMediaType()))
            .header("Accept", "application/json")
            .build()

        try {
            val response = httpClient.newCall(request).execute()
            response.use { resp ->
                val bodyString = resp.body?.string() ?: ""
                if (!resp.isSuccessful) {
                    val errorDetail = parseErrorDetail(bodyString, resp.code)
                    Log.e(TAG, "Device auth failed with HTTP ${resp.code}: $errorDetail")
                    return@withContext Result.failure(IOException(errorDetail))
                }

                val tokenResponse = parseTokenResponse(bodyString)
                tokenStore.saveTokens(
                    accessToken = tokenResponse.accessToken,
                    refreshToken = tokenResponse.refreshToken,
                    userId = tokenResponse.userId,
                    expiresInSeconds = tokenResponse.expiresIn
                )
                Log.d(TAG, "Device authentication successful. Tokens saved.")
                return@withContext Result.success(tokenResponse)
            }
        } catch (e: IOException) {
            Log.e(TAG, "Network failure during device auth: ${e.localizedMessage}", e)
            return@withContext Result.failure(IOException("Cannot reach NutriGuard backend at $baseUrl. Check network connection."))
        } catch (e: Exception) {
            Log.e(TAG, "Unexpected error during device auth: ${e.localizedMessage}", e)
            return@withContext Result.failure(e)
        }
    }

    /**
     * Refreshes access token using refresh token:
     * POST /api/v1/auth/refresh
     */
    suspend fun refreshToken(): Result<DeviceTokenResponse> = withContext(Dispatchers.IO) {
        val refreshToken = tokenStore.getRefreshToken()
        if (refreshToken.isNullOrBlank()) {
            return@withContext Result.failure(IOException("No refresh token available"))
        }

        val endpointUrl = "$baseUrl/api/v1/auth/refresh"
        val jsonPayload = JSONObject().apply {
            put("refresh_token", refreshToken)
        }

        Log.d(TAG, "Executing token refresh to $endpointUrl")

        val request = Request.Builder()
            .url(endpointUrl)
            .post(jsonPayload.toString().toRequestBody("application/json".toMediaType()))
            .header("Accept", "application/json")
            .build()

        try {
            val response = httpClient.newCall(request).execute()
            response.use { resp ->
                val bodyString = resp.body?.string() ?: ""
                if (!resp.isSuccessful) {
                    val errorDetail = parseErrorDetail(bodyString, resp.code)
                    Log.e(TAG, "Token refresh failed with HTTP ${resp.code}: $errorDetail")
                    return@withContext Result.failure(IOException(errorDetail))
                }

                val tokenResponse = parseTokenResponse(bodyString)
                tokenStore.saveTokens(
                    accessToken = tokenResponse.accessToken,
                    refreshToken = tokenResponse.refreshToken,
                    userId = tokenResponse.userId,
                    expiresInSeconds = tokenResponse.expiresIn
                )
                Log.d(TAG, "Token refresh successful. New tokens saved.")
                return@withContext Result.success(tokenResponse)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error during token refresh: ${e.localizedMessage}", e)
            return@withContext Result.failure(e)
        }
    }

    /**
     * Synchronous version of refresh for use inside OkHttp Interceptor.
     */
    fun refreshTokenSync(): Result<DeviceTokenResponse> {
        val refreshToken = tokenStore.getRefreshToken()
        if (refreshToken.isNullOrBlank()) {
            return Result.failure(IOException("No refresh token available"))
        }

        val endpointUrl = "$baseUrl/api/v1/auth/refresh"
        val jsonPayload = JSONObject().apply {
            put("refresh_token", refreshToken)
        }

        val request = Request.Builder()
            .url(endpointUrl)
            .post(jsonPayload.toString().toRequestBody("application/json".toMediaType()))
            .header("Accept", "application/json")
            .build()

        return try {
            val response = httpClient.newCall(request).execute()
            response.use { resp ->
                val bodyString = resp.body?.string() ?: ""
                if (!resp.isSuccessful) {
                    val errorDetail = parseErrorDetail(bodyString, resp.code)
                    return Result.failure(IOException(errorDetail))
                }

                val tokenResponse = parseTokenResponse(bodyString)
                tokenStore.saveTokens(
                    accessToken = tokenResponse.accessToken,
                    refreshToken = tokenResponse.refreshToken,
                    userId = tokenResponse.userId,
                    expiresInSeconds = tokenResponse.expiresIn
                )
                Result.success(tokenResponse)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Synchronous version of device authentication for fallback inside OkHttp Interceptor.
     */
    fun authenticateDeviceSync(appVersion: String = "1.0.0"): Result<DeviceTokenResponse> {
        val deviceId = tokenStore.getDeviceId()
        val endpointUrl = "$baseUrl/api/v1/auth/device"

        val jsonPayload = JSONObject().apply {
            put("device_id", deviceId)
            put("app_version", appVersion)
            put("platform", "ANDROID")
        }

        val request = Request.Builder()
            .url(endpointUrl)
            .post(jsonPayload.toString().toRequestBody("application/json".toMediaType()))
            .header("Accept", "application/json")
            .build()

        return try {
            val response = httpClient.newCall(request).execute()
            response.use { resp ->
                val bodyString = resp.body?.string() ?: ""
                if (!resp.isSuccessful) {
                    val errorDetail = parseErrorDetail(bodyString, resp.code)
                    return Result.failure(IOException(errorDetail))
                }

                val tokenResponse = parseTokenResponse(bodyString)
                tokenStore.saveTokens(
                    accessToken = tokenResponse.accessToken,
                    refreshToken = tokenResponse.refreshToken,
                    userId = tokenResponse.userId,
                    expiresInSeconds = tokenResponse.expiresIn
                )
                Result.success(tokenResponse)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun parseTokenResponse(responseBody: String): DeviceTokenResponse {
        val json = JSONObject(responseBody)
        val accessToken = (json.optString("accessToken").takeIf { it.isNotBlank() }
            ?: json.optString("access_token").takeIf { it.isNotBlank() })
            ?: throw IOException("Server response missing access_token / accessToken")

        val refreshToken = json.optString("refreshToken").takeIf { it.isNotBlank() }
            ?: json.optString("refresh_token").takeIf { it.isNotBlank() }
            ?: ""

        val tokenType = json.optString("tokenType").takeIf { it.isNotBlank() }
            ?: json.optString("token_type").takeIf { it.isNotBlank() }
            ?: "Bearer"

        val expiresIn = when {
            json.has("expiresIn") -> json.optLong("expiresIn", 3600L)
            json.has("expires_in") -> json.optLong("expires_in", 3600L)
            else -> 3600L
        }

        val userId = json.optString("userId").takeIf { it.isNotBlank() }
            ?: json.optString("user_id").takeIf { it.isNotBlank() }

        return DeviceTokenResponse(
            accessToken = accessToken,
            refreshToken = refreshToken,
            tokenType = tokenType,
            expiresIn = expiresIn,
            userId = userId
        )
    }

    private fun parseErrorDetail(responseBody: String, httpCode: Int): String {
        return try {
            val json = JSONObject(responseBody)
            val detail = json.optString("detail")
            if (detail.isNotBlank()) detail else "Authentication error (HTTP $httpCode)"
        } catch (e: Exception) {
            "Authentication failed with HTTP $httpCode"
        }
    }

    companion object {
        private const val TAG = "NutriGuardAuthService"
    }
}
