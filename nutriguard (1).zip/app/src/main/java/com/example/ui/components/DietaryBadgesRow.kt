package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ProductEntity
import com.example.ui.theme.RiskGreen
import com.example.ui.theme.RiskGreenBg
import com.example.ui.theme.RiskRed
import com.example.ui.theme.RiskRedBg

@Composable
fun DietaryBadgesRow(
    product: ProductEntity,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BadgeItem(label = "Gluten-Free", isCompliant = product.isGlutenFree)
        Spacer(modifier = Modifier.width(6.dp))
        BadgeItem(label = "Lactose-Free", isCompliant = product.isLactoseFree)
        Spacer(modifier = Modifier.width(6.dp))
        BadgeItem(label = "Vegan", isCompliant = product.isVegan)
        Spacer(modifier = Modifier.width(6.dp))
        BadgeItem(label = "Vegetarian", isCompliant = product.isVegetarian)
        Spacer(modifier = Modifier.width(6.dp))
        BadgeItem(label = "Halal", isCompliant = product.isHalal)
        Spacer(modifier = Modifier.width(6.dp))
        BadgeItem(label = "Kosher", isCompliant = product.isKosher)
    }
}

@Composable
private fun BadgeItem(label: String, isCompliant: Boolean) {
    val bg = if (isCompliant) RiskGreenBg else RiskRedBg
    val fg = if (isCompliant) RiskGreen else RiskRed
    val symbol = if (isCompliant) "✓" else "✕"

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bg)
            .border(1.dp, fg.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = "$symbol $label",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = fg
        )
    }
}
