package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Science
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.IngredientEntity
import com.example.data.model.RiskLevel
import com.example.ui.theme.RiskGreen
import com.example.ui.theme.RiskOrange
import com.example.ui.theme.RiskRed
import com.example.ui.theme.RiskYellow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IngredientDetailBottomSheet(
    ingredient: IngredientEntity?,
    onDismiss: () -> Unit
) {
    if (ingredient == null) return

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val (riskColor, riskText) = when (ingredient.riskLevel) {
        RiskLevel.SAFE -> RiskGreen to "🟢 SAFE"
        RiskLevel.MODERATE -> RiskYellow to "🟡 CONSUME IN MODERATION"
        RiskLevel.POTENTIAL_CONCERN -> RiskOrange to "🟠 POTENTIAL CONCERN"
        RiskLevel.HIGH_CONCERN -> RiskRed to "🔴 HIGH CONCERN / RESTRICTED"
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(riskColor.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Science,
                            contentDescription = "Scientific Analysis",
                            tint = riskColor
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "SCIENTIFIC PROFILE",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = ingredient.commonName,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            if (ingredient.scientificName.isNotBlank()) {
                Text(
                    text = ingredient.scientificName,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(riskColor)
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = riskText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.surface
                    )
                }

                if (!ingredient.eNumber.isNull_or_blank_safe()) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "E-Number: ${ingredient.eNumber}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(16.dp))

            // Scientific Fields
            InfoSectionItem("Description", ingredient.description)
            InfoSectionItem("Purpose in Food", ingredient.purposeInFood)
            InfoSectionItem("Evidence-Based Health Concerns", ingredient.healthConcerns)
            InfoSectionItem("Scientific Evidence Level", ingredient.evidenceLevel)
            InfoSectionItem("EFSA (European Food Safety) Status", ingredient.efsaStatus)
            InfoSectionItem("FDA (US Food & Drug) Status", ingredient.fdaStatus)

            if (ingredient.whoIarcClassification != null) {
                InfoSectionItem("WHO / IARC Classification", ingredient.whoIarcClassification, highlightColor = RiskRed)
            }

            InfoSectionItem("Countries Banned or Restricted", ingredient.countriesRestrictedOrBanned)
            InfoSectionItem("Acceptable Daily Intake (ADI)", ingredient.acceptableDailyIntake)
            InfoSectionItem("Known Side Effects & Toxicity", ingredient.sideEffects)
            InfoSectionItem("Allergen Information", ingredient.allergens)
            InfoSectionItem("Scientific References & Literature", ingredient.references)

            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}

@Composable
private fun InfoSectionItem(
    title: String,
    content: String,
    highlightColor: androidx.compose.ui.graphics.Color? = null
) {
    if (content.isBlank()) return

    Column(modifier = Modifier.padding(vertical = 6.dp)) {
        Text(
            text = title.uppercase(),
            style = MaterialTheme.typography.labelLarge,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = highlightColor ?: MaterialTheme.colorScheme.primary,
            letterSpacing = 0.5.sp
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = content,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

private fun String?.isNull_or_blank_safe(): Boolean {
    return this == null || this.trim().isEmpty()
}
