package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.viewmodel.MainViewModel

@Composable
fun ArchitectureAdminScreen(
    viewModel: MainViewModel
) {
    val ingredients by viewModel.allIngredients.collectAsState()
    val products by viewModel.allProducts.collectAsState()
    val history by viewModel.scanHistory.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Backend Architecture & Admin Specs",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Full Platform Design, PostgreSQL Schema, FastAPI REST API & Docker Specs",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            androidx.compose.material3.TabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("System Arch", fontSize = 12.sp) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("PostgreSQL Schema", fontSize = 12.sp) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("REST API Spec", fontSize = 12.sp) }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("Docker & Admin", fontSize = 12.sp) }
                )
            }
        }

        when (selectedTab) {
            0 -> {
                // System Architecture & Folder Structure
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "MODULAR FULL-STACK ARCHITECTURE",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "• Backend: Python FastAPI (Asynchronous ASGI)\n" +
                                        "• Database: PostgreSQL 16 + SQLAlchemy ORM\n" +
                                        "• OCR Pipeline: Tesseract v5 + OpenCV Pre-processing\n" +
                                        "• Cache & Message Queue: Redis\n" +
                                        "• Object Storage: MinIO (S3 compatible for label photos)\n" +
                                        "• Reverse Proxy: Nginx SSL Termination\n" +
                                        "• Mobile Client: Jetpack Compose / Flutter Native Engine\n" +
                                        "• Authentication: JWT (JSON Web Tokens)",
                                style = MaterialTheme.typography.bodyMedium
                            )

                            Spacer(modifier = Modifier.height(14.dp))
                            HorizontalDivider()
                            Spacer(modifier = Modifier.height(14.dp))

                            Text(
                                text = "SCALABLE PROJECT FOLDER STRUCTURE",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            CodeSnippetBox(
                                code = """
                                nutriguard_platform/
                                ├── backend/
                                │   ├── app/
                                │   │   ├── api/v1/          # Endpoints (auth, scan, ingredients)
                                │   │   ├── core/            # Security, config, JWT
                                │   │   ├── db/              # Postgres sessions, migrations
                                │   │   ├── models/          # SQLAlchemy ORM schemas
                                │   │   ├── services/        # OCR pipeline, AI analyzer
                                │   │   └── schemas/         # Pydantic request/response
                                │   ├── Dockerfile
                                │   └── requirements.txt
                                ├── nginx/
                                │   └── nginx.conf
                                ├── docker-compose.yml
                                └── mobile_android/          # Android Jetpack Compose app
                                """.trimIndent()
                            )
                        }
                    }
                }
            }

            1 -> {
                // PostgreSQL Database Schema Specification
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "POSTGRESQL DATABASE SCHEMA (SQL & SQLAlchemy)",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            CodeSnippetBox(
                                code = """
                                CREATE TABLE scientific_ingredients (
                                    id VARCHAR(64) PRIMARY KEY,
                                    common_name VARCHAR(255) NOT NULL,
                                    scientific_name VARCHAR(255),
                                    e_number VARCHAR(16) UNIQUE,
                                    category VARCHAR(64),
                                    description TEXT,
                                    purpose_in_food TEXT,
                                    health_concerns TEXT,
                                    evidence_level VARCHAR(64),
                                    countries_restricted TEXT,
                                    efsa_status VARCHAR(128),
                                    fda_status VARCHAR(128),
                                    who_iarc_classification VARCHAR(64),
                                    acceptable_daily_intake VARCHAR(64),
                                    side_effects TEXT,
                                    allergens TEXT,
                                    references TEXT,
                                    risk_level VARCHAR(32) NOT NULL,
                                    bad_for_diabetes BOOLEAN DEFAULT FALSE,
                                    bad_for_hypertension BOOLEAN DEFAULT FALSE,
                                    bad_for_kidney_disease BOOLEAN DEFAULT FALSE,
                                    bad_for_gout BOOLEAN DEFAULT FALSE,
                                    bad_for_pregnancy BOOLEAN DEFAULT FALSE,
                                    bad_for_children BOOLEAN DEFAULT FALSE,
                                    bad_for_high_cholesterol BOOLEAN DEFAULT FALSE
                                );

                                CREATE TABLE products (
                                    barcode VARCHAR(32) PRIMARY KEY,
                                    product_name VARCHAR(255) NOT NULL,
                                    brand VARCHAR(128),
                                    category VARCHAR(64),
                                    raw_ingredient_text TEXT,
                                    health_score INT NOT NULL,
                                    nova_group INT NOT NULL,
                                    sugar_grams NUMERIC(6,2),
                                    sodium_mg NUMERIC(8,2),
                                    saturated_fat_grams NUMERIC(6,2),
                                    has_artificial_sweeteners BOOLEAN,
                                    has_preservatives BOOLEAN,
                                    is_gluten_free BOOLEAN,
                                    is_lactose_free BOOLEAN,
                                    is_vegan BOOLEAN,
                                    is_vegetarian BOOLEAN,
                                    is_halal BOOLEAN,
                                    is_kosher BOOLEAN,
                                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                                );
                                """.trimIndent()
                            )
                        }
                    }
                }
            }

            2 -> {
                // REST API Specification
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "REST API SPECIFICATION (FASTAPI OpenAPI)",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            CodeSnippetBox(
                                code = """
                                POST /api/v1/auth/token
                                -> Returns JWT OAuth2 access token

                                GET /api/v1/products/{barcode}
                                -> Returns stored product analysis & scientific ingredients

                                POST /api/v1/ocr/scan-label
                                Body: Multipart form with photo label or raw text
                                -> Runs OpenCV pre-processing + Tesseract OCR
                                -> Normalizes E-numbers against DB
                                -> Returns Health Score 0-100 & personalized profile warnings

                                GET /api/v1/ingredients?search={query}&risk_level={level}
                                -> Returns paginated list of scientific ingredient records

                                PUT /api/v1/users/me/health-profile
                                -> Updates user health toggles (diabetes, hypertension, pregnancy, etc.)
                                """.trimIndent()
                            )
                        }
                    }
                }
            }

            3 -> {
                // Docker Deployment & Live Admin Metrics
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "ADMIN DASHBOARD METRICS",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                MetricBadge(title = "Scientific Records", count = "${ingredients.size}")
                                MetricBadge(title = "Stored Products", count = "${products.size}")
                                MetricBadge(title = "Total Scans", count = "${history.size}")
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                            HorizontalDivider()
                            Spacer(modifier = Modifier.height(16.dp))

                            Text(
                                text = "DOCKER DEPLOYMENT (docker-compose.yml)",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            CodeSnippetBox(
                                code = """
                                version: '3.8'

                                services:
                                  postgres:
                                    image: postgres:16-alpine
                                    environment:
                                      POSTGRES_DB: nutriguard
                                      POSTGRES_USER: admin
                                      POSTGRES_PASSWORD: ${'$'}{POSTGRES_PASSWORD}
                                    volumes:
                                      - postgres_data:/var/lib/postgresql/data

                                  redis:
                                    image: redis:7-alpine

                                  backend:
                                    build: ./backend
                                    environment:
                                      DATABASE_URL: postgresql://admin:${'$'}{POSTGRES_PASSWORD}@postgres:5432/nutriguard
                                      REDIS_URL: redis://redis:6379/0
                                    depends_on:
                                      - postgres
                                      - redis

                                  nginx:
                                    image: nginx:alpine
                                    ports:
                                      - "80:80"
                                      - "443:443"
                                    volumes:
                                      - ./nginx/nginx.conf:/etc/nginx/nginx.conf
                                """.trimIndent()
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}

@Composable
private fun CodeSnippetBox(code: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.background)
            .border(
                1.dp,
                MaterialTheme.colorScheme.outline,
                RoundedCornerShape(12.dp)
            )
            .padding(12.dp)
            .horizontalScroll(rememberScrollState())
    ) {
        Text(
            text = code,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun MetricBadge(title: String, count: String) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(
                1.dp,
                EmeraldPrimary.copy(alpha = 0.3f),
                RoundedCornerShape(16.dp)
            )
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(
            text = count,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = EmeraldPrimary
        )
        Text(
            text = title,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
