package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserHealthProfile
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.viewmodel.MainViewModel

@Composable
fun HealthProfileScreen(
    viewModel: MainViewModel
) {
    val profileState by viewModel.userProfile.collectAsState()
    val profile = profileState ?: UserHealthProfile()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Personal Health Profiles",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Active profiles automatically generate scientific warnings for scanned products",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Medical Health Conditions Section
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "MEDICAL CONDITIONS & LIFESTYLE STAGES",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    ProfileToggleRow(
                        title = "Diabetes / Glycemic Control",
                        subtitle = "Alerts high sugar (>5g), maltodextrin, dextrose, & artificial sweeteners",
                        checked = profile.hasDiabetes,
                        onCheckedChange = { viewModel.updateProfile(profile.copy(hasDiabetes = it)) }
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    ProfileToggleRow(
                        title = "Hypertension (High Blood Pressure)",
                        subtitle = "Alerts high sodium (>400mg), MSG (E621), & sodium preservers",
                        checked = profile.hasHypertension,
                        onCheckedChange = { viewModel.updateProfile(profile.copy(hasHypertension = it)) }
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    ProfileToggleRow(
                        title = "Kidney Disease / Renal Health",
                        subtitle = "Alerts heavy sodium, potassium, & phosphate additives (E338-E343)",
                        checked = profile.hasKidneyDisease,
                        onCheckedChange = { viewModel.updateProfile(profile.copy(hasKidneyDisease = it)) }
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    ProfileToggleRow(
                        title = "Gout / High Uric Acid",
                        subtitle = "Alerts high fructose corn syrup, purine boosters, & yeast extracts",
                        checked = profile.hasGout,
                        onCheckedChange = { viewModel.updateProfile(profile.copy(hasGout = it)) }
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    ProfileToggleRow(
                        title = "Pregnancy & Lactation",
                        subtitle = "Alerts nitrates/nitrites, saccharin, titanium dioxide, & unpasteurized additives",
                        checked = profile.isPregnant,
                        onCheckedChange = { viewModel.updateProfile(profile.copy(isPregnant = it)) }
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    ProfileToggleRow(
                        title = "Children & Toddlers",
                        subtitle = "Alerts Southampton Six hyperactivity dyes (E102, E110, E129) & high sugar",
                        checked = profile.forChildren,
                        onCheckedChange = { viewModel.updateProfile(profile.copy(forChildren = it)) }
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    ProfileToggleRow(
                        title = "High Cholesterol & Cardiovascular",
                        subtitle = "Alerts saturated fats (>4g), palm oil, trans fats, & hydrogenated oils",
                        checked = profile.hasHighCholesterol,
                        onCheckedChange = { viewModel.updateProfile(profile.copy(hasHighCholesterol = it)) }
                    )
                }
            }
        }

        // Dietary & Allergen Exclusions
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "ALLERGEN & DIETARY RESTRICTIONS",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    ProfileToggleRow(
                        title = "Strict Gluten-Free",
                        subtitle = "Warn if wheat, barley, rye, or gluten cross-contact present",
                        checked = profile.avoidGluten,
                        onCheckedChange = { viewModel.updateProfile(profile.copy(avoidGluten = it)) }
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    ProfileToggleRow(
                        title = "Lactose Intolerance",
                        subtitle = "Warn if milk, whey, butter, or lactose derived ingredients present",
                        checked = profile.avoidLactose,
                        onCheckedChange = { viewModel.updateProfile(profile.copy(avoidLactose = it)) }
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    ProfileToggleRow(
                        title = "Require Vegan Suitability",
                        subtitle = "Flag any animal-derived ingredients or gelatin",
                        checked = profile.requireVegan,
                        onCheckedChange = { viewModel.updateProfile(profile.copy(requireVegan = it)) }
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    ProfileToggleRow(
                        title = "Require Halal Compliance",
                        subtitle = "Flag pork derivatives, alcohol carriers, & non-halal additives",
                        checked = profile.requireHalal,
                        onCheckedChange = { viewModel.updateProfile(profile.copy(requireHalal = it)) }
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    ProfileToggleRow(
                        title = "Require Kosher Compliance",
                        subtitle = "Flag non-kosher processing agents or uncertified origins",
                        checked = profile.requireKosher,
                        onCheckedChange = { viewModel.updateProfile(profile.copy(requireKosher = it)) }
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}

@Composable
private fun ProfileToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = MaterialTheme.colorScheme.surface,
                checkedTrackColor = EmeraldPrimary
            )
        )
    }
}
