package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Bento Grid Base Palette
val EmeraldPrimary = Color(0xFF059669)
val EmeraldOnPrimary = Color(0xFFFFFFFF)
val EmeraldContainer = Color(0xFFD1FAE5)
val EmeraldOnContainer = Color(0xFF065F46)

val DarkForestBackground = Color(0xFF0F172A)
val DarkForestSurface = Color(0xFF1E293B)
val DarkForestBorder = Color(0xFF334155)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightBorder = Color(0xFFE2E8F0)

// Bento Accent Badges
val BentoBlueBg = Color(0xFFEFF6FF)
val BentoBlueFg = Color(0xFF2563EB)
val BentoPurpleBg = Color(0xFFF3E8FF)
val BentoPurpleFg = Color(0xFF7C3AED)
val BentoTealBg = Color(0xFFCCFBF1)
val BentoTealFg = Color(0xFF0D9488)

// Color-coded Risk Levels for Food Ingredients
val RiskGreen = Color(0xFF16A34A)      // 🟢 Safe
val RiskYellow = Color(0xFFD97706)     // 🟡 Consume in moderation
val RiskOrange = Color(0xFFEA580C)     // 🟠 Potential concern
val RiskRed = Color(0xFFDC2626)        // 🔴 High concern or restricted

val RiskGreenBg = Color(0xFFF0FDF4)
val RiskYellowBg = Color(0xFFFFFBEE)
val RiskOrangeBg = Color(0xFFFFEDD5)
val RiskRedBg = Color(0xFFFEF2F2)

val AccentGold = Color(0xFFF59E0B)
val SlateTextPrimary = Color(0xFF0F172A)
val SlateTextSecondary = Color(0xFF64748B)

