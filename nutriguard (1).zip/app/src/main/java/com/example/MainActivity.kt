package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Science
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.ArchitectureAdminScreen
import com.example.ui.screens.HealthProfileScreen
import com.example.ui.screens.ProductDetailScreen
import com.example.ui.screens.ScanHomeScreen
import com.example.ui.screens.ScanHistoryScreen
import com.example.ui.screens.ScientificLibraryScreen
import com.example.ui.theme.NutriGuardTheme
import com.example.ui.viewmodel.MainViewModel

sealed class BottomNavItem(val route: String, val title: String, val icon: ImageVector) {
    object Scan : BottomNavItem("scan_home", "Scanner", Icons.Default.QrCodeScanner)
    object Result : BottomNavItem("product_detail", "Analysis", Icons.Default.Assessment)
    object Library : BottomNavItem("scientific_library", "E-Library", Icons.Default.Science)
    object Profiles : BottomNavItem("health_profiles", "Health Profiles", Icons.Default.MedicalServices)
    object History : BottomNavItem("scan_history", "History", Icons.Default.History)
    object Architecture : BottomNavItem("architecture_admin", "Specs/Admin", Icons.Default.AdminPanelSettings)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NutriGuardTheme {
                val viewModel: MainViewModel = viewModel(
                    factory = MainViewModel.Factory(applicationContext)
                )
                NutriGuardApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun NutriGuardApp(viewModel: MainViewModel) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val navItems = listOf(
        BottomNavItem.Scan,
        BottomNavItem.Result,
        BottomNavItem.Library,
        BottomNavItem.Profiles,
        BottomNavItem.History,
        BottomNavItem.Architecture
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                navItems.forEach { item ->
                    val isSelected = currentRoute == item.route
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = {
                            navController.navigate(item.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(imageVector = item.icon, contentDescription = item.title) },
                        label = {
                            Text(
                                text = item.title,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = BottomNavItem.Scan.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(BottomNavItem.Scan.route) {
                ScanHomeScreen(
                    viewModel = viewModel,
                    onNavigateToResult = {
                        navController.navigate(BottomNavItem.Result.route)
                    }
                )
            }

            composable(BottomNavItem.Result.route) {
                ProductDetailScreen(
                    viewModel = viewModel,
                    onBack = {
                        navController.navigate(BottomNavItem.Scan.route)
                    }
                )
            }

            composable(BottomNavItem.Library.route) {
                ScientificLibraryScreen(
                    viewModel = viewModel
                )
            }

            composable(BottomNavItem.Profiles.route) {
                HealthProfileScreen(
                    viewModel = viewModel
                )
            }

            composable(BottomNavItem.History.route) {
                ScanHistoryScreen(
                    viewModel = viewModel,
                    onSelectHistoryItem = {
                        navController.navigate(BottomNavItem.Result.route)
                    }
                )
            }

            composable(BottomNavItem.Architecture.route) {
                ArchitectureAdminScreen(
                    viewModel = viewModel
                )
            }
        }
    }
}
